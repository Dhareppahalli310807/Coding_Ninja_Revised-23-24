import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <form className="form">
        <h3 className="form-heading">Sign Up</h3>
        <input className="form-input" placeholder="Username" />
        <input className="form-input" placeholder="Email" />
        <input className="form-input" placeholder="Password" />
        <div className="form-buttons">
          <button className="form-button cancel-button">Cancel</button>
          <button className="form-button login-button">Login</button>
        </div>
      </form>
    </div>
  );
}
