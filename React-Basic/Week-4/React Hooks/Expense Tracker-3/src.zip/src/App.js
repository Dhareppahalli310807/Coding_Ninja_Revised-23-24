import React, { useReducer } from "react";
import ExpenseForm from "./components/ExpenseForm/ExpenseForm";
import ExpenseInfo from "./components/ExpenseInfo/ExpenseInfo";
import ExpenseList from "./components/ExpenseList/ExpenseList";
import "./App.css";

// Reducer function to manage state
const reducer = (state, action) => {
  switch (action.type) {
    case "ADD_TRANSACTION":
      return [...state, action.payload];
    case "DELETE_TRANSACTION":
      return state.filter(expense => expense.id !== action.payload);
    default:
      return state;
  }
};

function App() {
  const [expenses, dispatch] = useReducer(reducer, []);

  const addTransaction = transaction => {
    dispatch({ type: "ADD_TRANSACTION", payload: transaction });
  };

  const deleteTransaction = id => {
    dispatch({ type: "DELETE_TRANSACTION", payload: id });
  };

  return (
    <>
      <h2 className="mainHeading">Expense Tracker</h2>
      <div className="App">
        <ExpenseForm onAddTransaction={addTransaction} />
        <div className="expenseContainer">
          <ExpenseInfo expenses={expenses} />
          <ExpenseList expenses={expenses} onDeleteTransaction={deleteTransaction} />
        </div>
      </div>
    </>
  );
}

export default App;
